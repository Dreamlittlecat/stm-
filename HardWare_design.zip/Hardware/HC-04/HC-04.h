#ifndef __HC04_H
#define __HC04_H

#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "magic.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_usart.h"
  	#include "led.h"
void uart3_init(u32 bound);

#endif /*__HC04_H*/

