#ifndef hc_sr04
#define hc_sr04

#include "magic.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_rcc.h"
#include "misc.h"
#include "motor_control.h"
#include "led.h"

//������ trig
#define Trig GPIO_Pin_1
#define trig_gpio GPIOA



//������ echo

#define Echo GPIO_Pin_2
#define echo_gpio GPIOA



//������ trig2
#define Trig2 GPIO_Pin_1
#define trig2_gpio GPIOC
 


//������ echo2

#define Echo2 GPIO_Pin_2
#define echo2_gpio GPIOC



//������ trig3
#define Trig3 GPIO_Pin_3
#define trig3_gpio GPIOC


//������ echo3

#define Echo3 GPIO_Pin_12
#define echo3_gpio GPIOB


//1,2,3��Ӧ������


#define dist_Echo_PORT GPIOA
#define dist_Trig_PORT GPIOA
#define dist_Echo_PIN GPIO_Pin_2
#define dist_Trig_Pin GPIO_Pin_1

#define dist_Echo_RCC RCC_APB2Periph_GPIOA
#define dist_Trig_RCC RCC_APB2Periph_GPIOA
void HCSR04_init(void);
void TIM4_Init(void);
int GetDistance(int num);
void judge();
int trace_static();
void trace_dynamic();
#endif