

#include "hc-sr04.h"
#include "stm32f10x_tim.h"
#include "led.h"
#include "EXIT-TEST.h"
void HCSR04_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;//定义结构体变量
	
    RCC->APB2ENR |= RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF ; 
	 GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);//完全禁用SWD及JTAG 
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);     //禁用JTAG
    //初始化echo
	GPIO_InitStructure.GPIO_Pin=Echo;  //选择你要设置的IO口
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;	 //设置浮空输入
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;	  //设置传输速率
	GPIO_Init(echo_gpio,&GPIO_InitStructure); 	   /* 初始化GPIO */
    GPIO_InitStructure.GPIO_Pin=Echo2;  
    GPIO_Init(echo2_gpio,&GPIO_InitStructure); 
    GPIO_InitStructure.GPIO_Pin=Echo3;  
    GPIO_Init(echo3_gpio,&GPIO_InitStructure); 
    
    
    
	GPIO_InitStructure.GPIO_Pin=Trig;  //选择你要设置的IO口
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;	 //设置推挽输出
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;	  //设置传输速率
	GPIO_Init(trig_gpio,&GPIO_InitStructure); 	   /* 初始化GPIO */

    GPIO_InitStructure.GPIO_Pin=Trig2;
    GPIO_Init(trig2_gpio,&GPIO_InitStructure); 	
    GPIO_InitStructure.GPIO_Pin=Trig3;
    GPIO_Init(trig3_gpio,&GPIO_InitStructure); 	


}
void TIM4_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);//使能TIM4时钟
	
	 TIM_TimeBaseInitStructure.TIM_Prescaler = 0;
	  TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	  TIM_TimeBaseInitStructure.TIM_Period = 0xffff;
	  TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
	  TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	  TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);   
	  TIM_PrescalerConfig(TIM4,71, TIM_PSCReloadMode_Immediate);   
	
	  TIM_ARRPreloadConfig(TIM4,DISABLE);  
	  TIM_SetCounter(TIM4,0);			 //TIM4计数值清零
	  TIM_Cmd(TIM4,DISABLE); 			 //TIM4计数器失能
}

int GetDistance(int num)
{
    
    int dis;
	int count;
   TIM_SetCounter(TIM4,0);	
    if(num==1)
    {
    
    
    GPIO_SetBits(trig_gpio,Trig);   //将Trig设置为高电平
    delay_us(10); 
    GPIO_ResetBits(trig_gpio,Trig); 
    delay_us(100);  
   	while(!GPIO_ReadInputDataBit(echo_gpio,Echo)) ;
	TIM_Cmd(TIM4,ENABLE);    //开启计数器
       //开启定时器开始计时
    while(GPIO_ReadInputDataBit(echo_gpio,Echo)&&( TIM_GetCounter(TIM4)<=12000)){
       
   
    };    //等待echo置低
    count = TIM_GetCounter(TIM4);
  //  printf("left count:%D\n",count);
	TIM_Cmd(TIM4,DISABLE);   //关闭计数器
   // printf("trig1:\t");
    }
    else if(num==2){
        // TIM_SetCounter(TIM4,0);	
    GPIO_SetBits(trig2_gpio,Trig2);   //将Trig设置为高电平
    delay_us(10);  
    GPIO_ResetBits(trig2_gpio,Trig2);
    delay_us(100);  
    while(!GPIO_ReadInputDataBit(echo2_gpio,Echo2)) ;
	TIM_Cmd(TIM4,ENABLE);    //开启计数器
       //开启定时器开始计时
	while(GPIO_ReadInputDataBit(echo2_gpio,Echo2)&&( TIM_GetCounter(TIM4)<=12000)){};   //等待echo置低
        count = TIM_GetCounter(TIM4);
     //   printf("right count:%D\n",count);
	TIM_Cmd(TIM4,DISABLE);   //关闭计数器
  //  printf("trig2:\t");
        
        
    }else if(num==3){
        // TIM_SetCounter(TIM4,0);	
    GPIO_SetBits(trig3_gpio,Trig3);   //将Trig设置为高电平
    delay_us(10);  
    GPIO_ResetBits(trig3_gpio,Trig3);
    delay_us(100);  
    while(!GPIO_ReadInputDataBit(echo3_gpio,Echo3)) ;
	TIM_Cmd(TIM4,ENABLE);    //开启计数器
       //开启定时器开始计时
        while(GPIO_ReadInputDataBit(echo3_gpio,Echo3)&&( TIM_GetCounter(TIM4)<=12000)){};   //等待echo置低,设置计数上限为12000，即两米，实测发现设置为4m程序容易跑飞
        count = TIM_GetCounter(TIM4);
     //   printf("mid count:%D\n",count);
	TIM_Cmd(TIM4,DISABLE);   //关闭计数器

    //printf("trig3:\t");
    }
    
    
  /*  
	GPIO_ResetBits(dist_Echo_PORT,dist_Echo_PIN);			//echo端口复位
	GPIO_ResetBits(dist_Trig_PORT,dist_Trig_Pin);			//trig端口复位
    
    
    		 //TIM4计数值清零
	GPIO_SetBits(dist_Trig_PORT,dist_Trig_Pin);		          //trig置高 发出10us的高电平信号 
	delay_us(10); 
	GPIO_ResetBits(dist_Trig_PORT,dist_Trig_Pin);
	delay_us(100);  		  
	while(GPIO_ReadInputDataBit(dist_Echo_PORT, dist_Echo_PIN) == 0);
	TIM_Cmd(TIM4,ENABLE);    //开启计数器
       //开启定时器开始计时
	while(GPIO_ReadInputDataBit(dist_Echo_PORT, dist_Echo_PIN));   //等待echo置低
	TIM_Cmd(TIM4,DISABLE);   //关闭计数器
*/
	//获取计数器值
	dis = (int)count/60.82;//转换为距离,即29.41us超声波能传播1cm
	return dis;
}
void judge(){
    printf("hcsr04:\t");
    //LED_BLUE_TOGGLE;
    int safe_distance=20;
    int distance[3]={0};
    int num=2;
    for(int k=0;k<num;k++)
    for(int i=0;i<3;i++){
       distance[i]+=GetDistance(i+1);
            }
    int left_,right_,mid;
    left_=distance[0]/num;
    right_=distance[1]/num;
    mid=distance[2]/num;
            
    int mid_flag=0,left_flag=0,right_flag=0;  
  printf("left:%d mid:%d right:%d \n ",left_,mid,right_);
           
    if(left_>safe_distance&mid>safe_distance&right_>safe_distance)
    {
           
        forward();
         //printf("forward\n");
    }else 
    {
    
        
        if(mid<safe_distance){
            mid_flag=1;
            
        }
        if(right_<safe_distance){
        right_flag=1;
        }
        if(left_<safe_distance){
        left_flag=1;
        }
     //   printf("left:%d mid:%d right:%d  ",left_flag,mid_flag,right_flag);
        
        if(left_flag&mid_flag&right_flag){
            left();
            //printf("left\n");
           // delay_ms(1000);
           //  forward();
            return;
        
        }
        
        if(!left_flag&!mid_flag&right_flag){
            left();
          //  printf("left\n");
          //  delay_ms(500);
           //  forward();
            return;
        
        }
        
        if(!left_flag&mid_flag&!right_flag){
           if(left_>right_){
           left();
              // printf("left\n");
              // delay_ms(300);
              // forward();
           }else{
            right();
             //  printf("right\n");
              // delay_ms(300);
              // forward();
           }
           return;
        }
        if(left_flag&!mid_flag&!right_flag){
            right();
           // printf("right\n");
          //  delay_ms(200);
          //  forward();
            return;
        }
        if(left_flag&mid_flag&!right_flag){
            right();
           // printf("right\n");
           // delay_ms(800);
           // forward();
            return;
        }
        if(!left_flag&mid_flag&right_flag){
            left();
            //printf("left\n");
         //   delay_ms(200);
          //  forward();
            return;
        }
        if(!left_flag&mid_flag&!right_flag){
           
            forward();
            //printf("forward\n");
            return;
        }
        }
        //第一版判断算法
  /*     
       int k=(mid>(left_>right_?left_:right_))?mid:(left_>right_?left_:right_);
     if(left_>20&mid>20&right_>20)
    {
           
        forward();
         printf("forward\n");
    }else if(k<20){
        left();
    }
  else  if(k==mid){
            if(k>30){
         forward();
            printf("forward\n");}
            else{
                
                back();
                printf("back\n");
            }
        }
        else if(k==left_)
        {
            if(k>30)
            {  left();
             printf("left\n");}else{
             back();
                 printf("back\n");
             }
        }else if(k==right_)
        {
            if(k>30){
        right();
             printf("right\n");}else{
             back();
                 printf("back\n");
             }
        }*/
    
   

}



int left_0,left_1,right_0,right_1,mid_0,mid_1;
int trace_static(){
    
    left_0=left_1=right_0=right_1=mid_0=mid_1=0;
    
    
    int distance[3]={0};
    int num=3;
    for(int k=0;k<num;k++)
    for(int i=0;i<3;i++)
    {
    distance[i]+=GetDistance(i+1);
            }
    int left_,right_,mid;
    left_=distance[0]/num;
    right_=distance[1]/num;
    mid=distance[2]/num;
    printf("left:%d mid:%d right:%d  \n",left_,mid,right_);
            left_0=left_;
            right_0=right_;
            mid_0=mid;
        
            int k=(mid<(left_<right_?left_:right_))?mid:(left_<right_?left_:right_);
            if(k==mid){
                if(k<20&&k>10){
                return 1;
                }
            if(k>20){
         
            
            forward();}
          if(k<10){
          back();
          }
            
        }
        else if(k==left_)
        {
            left();
        }else if(k==right_)
        {
            right();
        }
        return 0;
}



//追踪
void trace_dynamic(){
    printf("trace start\n");
    int distance[3]={0};
    int num=1;
    for(int k=0;k<num;k++)
    for(int i=0;i<3;i++)
    {
    distance[i]+=GetDistance(i+1);
            }
    printf("trace end\n");
    int left_,right_,mid;
    left_=distance[0]/num;
    right_=distance[1]/num;
    mid=distance[2]/num;
            
            left_1=left_-left_0;
            right_1=right_-right_0;
            mid_1=mid-mid_0;
            
            left_0=left_;
            right_0=right_;
            mid_0=mid;
            
             printf("left:%d mid:%d right:%d  \n",left_,mid,right_);
            // printf("left_1:%d mid_1:%d right_1:%d  \n",left_1,mid_1,right_1);
            
            if(mid_1>25){
                trace_init_flag=1;
                printf("重新确认追踪\n");
            }
            
            if(mid>20||mid_1>3){
                
            forward();
                
            }else if(mid<10||mid_1<-3){
                
            back();
                
            } else{
                stop();
                 printf("keep stationary\n");
            }
            
        
            
}
