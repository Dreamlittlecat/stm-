#include "bsp_pwm.h"
#define L298_enA   
#define L298_enB   

#define High    1
#define Low     0
 void motor_control_init();
#define IN1(a) if (a)  \
	GPIO_SetBits(GPIOA,GPIO_Pin_6);\
else  \
	GPIO_ResetBits(GPIOA,GPIO_Pin_6)
 
#define IN2(a) if (a)  \
	GPIO_SetBits(GPIOA,GPIO_Pin_3);\
else  \
	GPIO_ResetBits(GPIOA,GPIO_Pin_3)
 
#define IN3(a) if (a)  \
	GPIO_SetBits(GPIOA,GPIO_Pin_4);\
else  \
	GPIO_ResetBits(GPIOA,GPIO_Pin_4)
 
#define IN4(a) if (a)  \
	GPIO_SetBits(GPIOA,GPIO_Pin_5);\
else  \
	GPIO_ResetBits(GPIOA,GPIO_Pin_5)
 

/*
#define IN5(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_6);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_6)

 #define IN6(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_7);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_7)



 #define IN7(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_8);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_8)

 #define IN8(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_9);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_9)
 */
void Motor_12_Config(void);
 
void Motor_1_STOP(void);
void Motor_1_PRun(void);
void Motor_1_NRun(void);
 
void Motor_2_STOP(void);
void Motor_2_PRun(void);
void Motor_2_NRun(void);


//void Motor_3_STOP(void);
//void Motor_3_PRun(void);
//void Motor_3_NRun(void);
// 
//void Motor_4_STOP(void);
//void Motor_4_PRun(void);
//void Motor_4_NRun(void);


void forward();
void back();
  void left();
 void right();
 void stop();
void set_velocity(int v);
void buzzer(int t);
extern int move_flag;
