#ifndef __BMP_H
#define __BMP_H

extern unsigned char BMP1[];
extern unsigned char BMP2[];
extern unsigned char gImage_pic[];
extern unsigned char* quanhuang_gif[]  ;
#endif


