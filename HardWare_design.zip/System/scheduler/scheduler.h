#ifndef __SCHEDULER_H
#define __SCHEDULER_H

#include "magic.h"

void Scheduler_TickCnt(void); 
void Scheduler_Run(void);   // �������



#endif

