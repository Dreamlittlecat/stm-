工程文件位于project文件夹；
模块函数实现.c文件位于Hardware文件夹；
各个模块文件夹内有.c和.h文件