
    
//HardWare_design test1 �Ŀ���
#include "magic.h"                     // ����magic.c�Լ򻯴��빤��; ע��: ��ȡ������ԭ��sys.c��delay.c��usart.c�����ã��������ظ������ͻ
#include "led.h"

#include "rtc.h"
#include "EXIT-TEST.h"
#include "oled.h"
#include "bsp_pwm.h"
#include "motor_control.h"
//#include "HC-04.h"
#include "hc-sr04.h"
#include "sg90.h"
#include "environment.h"
#include "iwdg.h"
#include "pid.h"
extern int count;
extern int mode_key_flag;//ͨ�������жϸı��־������ѡ���ж�ģʽ



void display();
void Oled_show();
void oled_screen();
void dilemma_judge();


int main(void)
{	    
    // ������ʼ��������������magic.c�ļ��� ��ע�⣬ϵͳʱ�ӳ�ʼ��SystemInit�������������ļ��е��ã�����Ϊ72MHz
    System_Usart1Init(9600);         // ��ʼ��USART1��Ϊ������Ϣ����� ������magic.c�ļ���   
    
    System_SysTickInit();              // ��ʼ��systickʱ�ӣ�ʹ��delay_ms��delay_us����������
    
        vLed_Init();                       // LED ��ʼ��
   
        LED_BLUE_ON ;   
        LED_RED_ON ;
		vRTC_Init();      
        motor_control_init();
    
        set_velocity(20);
        
        OLED_Init();
         // printf("s1:%d\n",GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1));    
        //int dist=0;
        HCSR04_init();//��������ʼ��
        TIM4_Init(); //tim4ʱ�ӳ�ʼ��
        //int count=0;
       // delay_ms(500);
      //  sg90_init();
         
        /* 
     
         for(int i=0;i<5;i++)
         {
             delay_ms(500);
                set_Xdegree_free(20*i);
             set_Ydegree_free(20*i);
         }
         */
    
        //  Oled_show();
        // TIM_PwmInit(GPIOA, GPIO_Pin_10, TIM1, 3, 7200, 200, 0);     // ʾ��3�� PA10���ţ�TIM1_CH3, 1��������1us(��72000000/72), PWM�ź�����: 20us(��1us x 20), ��ʼ����0ms(��ռ�ձȵ�ʱ����
        // TIM_SetCCR(TIM1, 3, 15);  // �ı�PA10�����������50s(��Ϊ��һ�����ó���1����Ϊ1us,����5�������ź�Ϊ5us)
	//right();
         //display();
       //  back();
       // Motor_2_PRun();
       //  Motor_1_PRun();
       //  forward();
       /*  while(1){
             delay_ms(100);
            if(trace_init_flag)
            {
                if(trace_static())
                {  
                    trace_init_flag=0;
                    printf("trace_init_finish");
                }
                
            }else{
           // printf("trace_dynamic");
            trace_dynamic();
                
            }
         
         }*/
         
        EXTIX_Init();
        oled_screen();
       
         
        /*  while(1){
             delay_ms(100);
            if(trace_init_flag)
            {
                if(trace_static())
                {  
                    trace_init_flag=0;
                    printf("trace_init_finish");
                }
                
            }else{
           // printf("trace_dynamic");
            trace_dynamic();
                
            }
         
         }
         */
         
        int flag; flag=1;
        IWDG_Init(4,0xfff); //���ÿ��Ź�,�����ܷ���������
        buzzer(100);
        forward();
       // set_velocity(10);
      /*  while(1){
        printf("mid:%D\n",GetDistance(3));
            printf("l:%D\n",GetDistance(1));
             printf("r:%D\n",GetDistance(2));
            delay_ms(100);
          IWDG_Feed();
        }*/
        //int mode
        mode_key_flag=1;
        
      //  PID pid;
       // PID_Init(&pid,2,3,2,2,15);
       /* forward();
        {
            for(int i=0;i<10;i++)
        {      delay_ms(1000);
            //set_velocity(i*10);
            TIM_SetCCR(TIM8, 1, i*10);
            TIM_SetCCR(TIM8, 2, i*2);
            printf("i:%D\n",i);
        }
        
        }*/
      
while(1)
	{
        
        
       LED_BLUE_TOGGLE;
        delay_ms(big_cycle_t);
        if(flag==1)
        {
                
             //   printf("judge\n");
        // forward();
       // LED_RED_TOGGLE;
        judge();
               // mode_2();
        }
        else if(flag==0)
        {
              //  mode_1();
             // printf("red_find\n");
               //  LED_BLUE_TOGGLE;
        red_find_road();
        }else if(flag==2){
            delay_ms(300);
        buzzer(100);
        stop();
        }else if(flag==3){
            
            
            
            if(trace_init_flag)
            {
                if(trace_static())
                {  
                    trace_init_flag=0;
                    printf("trace_init_finish");
                }
                
            }else{
           // printf("trace_dynamic");
            trace_dynamic();
                
            }
        
          //  trace_init();
        }
      else if(flag==4){
          stop();
            Oled_show();
            oled_screen();
        //  forward();
        /*  while(volecity!=10)
          {
            PID_SingleCalc(&pid,10,volecity);
              set_v=set_v+pid.output;
             set_velocity(set_v);
              delay_ms(50);
              printf("pid->output:%f volecity:%D",pid.output,volecity);
            IWDG_Feed();
          }*/
          
          IWDG_Feed();
            mode_key_flag=2;
            display();
          
      
      }
       // printf("flag:%d",flag);
        flag=mode_key_flag;
        IWDG_Feed();
        if(flag==1)
        dilemma_judge();
         
    }

   
}

void display(){
       // OLED_Clear();
       // OLED_ShowString(3,4,"DISPLAY-test",8);
        delay_ms(500);
        printf("display:\n");
        set_v=20;
        set_velocity(20);
       // printf("forward,v:17\n");
      //  OLED_ShowString(3,4,"forward,v:20    ",8);
     /*   forward();
        IWDG_Feed();
        
        delay_ms(5000); */
       // OLED_ShowString(3,4,"back,v:20       ",8);
    /*    back();
       /// printf("back\n");
        IWDG_Feed();
        delay_ms(5000); */
       // OLED_ShowString(3,4,"left,v:20       ",8);
    
    forward();
     for(int i=0;i<5;i++){
          set_velocity(10+2*(i+1));
          delay_ms(2000);
              IWDG_Feed();
          }
     
          back();
          
          for(int i=0;i<5;i++){
          set_velocity(20-2*(i+1));
          delay_ms(2000);
              IWDG_Feed();
          }
    
    set_velocity(20);
        left();
      //  printf("left\n");
        IWDG_Feed();
        delay_ms(5000); 
      //  OLED_ShowString(3,4,"right,v:20      ",8);
        right();
       // printf("right\n");
        IWDG_Feed();
        delay_ms(5000); 
       // OLED_ShowString(3,4,"stop,v:20       ",8);
        stop();
       // printf("stop\n");
        IWDG_Feed();
        delay_ms(5000); 
       // OLED_ShowString(3,4,"over-forward,v:20",8);
        printf("display-over,forward\n");
        forward();
        IWDG_Feed();
}

void Oled_show(){
                OLED_Clear();
                OLED_ShowString(3,4,"HARDWARE-XIA&TU",8);
                delay_ms(1000);
                OLED_Draw12864BMP(quanhuang_gif[0]);
                OLED_Drawgif( quanhuang_gif);
                OLED_ShowString(3,4,"HARDWARE-XIA&TU",16);
//             delay_ms(1000);
//              OLED_Draw12864BMP(BMP1);
//             delay_ms(1000);
//              OLED_Draw12864BMP(BMP2);

} 
void oled_screen(){
    OLED_Clear();
    OLED_ShowString(0,0,"v:",8);
     OLED_ShowString(88,0,"cm/s",8);
    OLED_ShowString(0,4,"count:",8);
    OLED_ShowString(0,2,"s:",8);
    OLED_ShowString(88,2,"cm",8);
}

void dilemma_judge(){
    
    if(volecity==0&&move_flag!=0&&move_flag!=-1){
    back();
    delay_ms(200);
        buzzer(100);
        printf("dilemma.back");
       // left();
    }else if(volecity==0&&move_flag==-1){
          forward();
    delay_ms(200);
         buzzer(100);
        printf("dilemma.forward");
    }
   // printf("near_:%D",GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0));
    
    
    if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)){
        back();
        delay_ms(400);
        printf("near.back");
    }
}



